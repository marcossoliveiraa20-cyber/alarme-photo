plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alarmefoto"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.alarmefoto"
        minSdk = 27
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("alarmefoto.jks")
            storePassword = "alarmefoto123"
            keyAlias = "alarmefoto"
            keyPassword = "alarmefoto123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
