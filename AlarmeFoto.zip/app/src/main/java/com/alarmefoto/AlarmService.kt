package com.alarmefoto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopAlarm()
            return START_NOT_STICKY
        }
        val id = intent?.getIntExtra("id", -1) ?: -1
        val a = Store.load(this).find { it.id == id }

        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel("alarm", "Alarmes", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)

        val ring = Intent(this, RingActivity::class.java).putExtra("id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val fs = PendingIntent.getActivity(
            this, id, ring, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, AlarmService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (a != null) "%02d:%02d".format(a.hour, a.minute) else "Hora de acordar!"
        val b = Notification.Builder(this, "alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Alarme")
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(fs)
            .setFullScreenIntent(fs, true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Desligar", stop
                ).build()
            )
        val bmp = a?.photo?.let { Photos.load(it, 512) }
        if (bmp != null) {
            b.setLargeIcon(bmp)
            b.setStyle(Notification.BigPictureStyle().bigPicture(bmp))
        }
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }

        raiseVolume()
        startSound()
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ stopAlarm() }, 10 * 60 * 1000L)
        return START_NOT_STICKY
    }

    private fun raiseVolume() {
        try {
            val am = getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max / 2) {
                am.setStreamVolume(AudioManager.STREAM_ALARM, max * 3 / 4, 0)
            }
        } catch (e: Exception) {
        }
    }

    private fun newPlayer(setup: (MediaPlayer) -> Unit): MediaPlayer? {
        var p: MediaPlayer? = null
        return try {
            p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            p.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            p.isLooping = true
            setup(p)
            p.prepare()
            p.start()
            p
        } catch (e: Exception) {
            p?.release()
            null
        }
    }

    private fun startSound() {
        player?.release()
        player = newPlayer {
            it.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        } ?: newPlayer {
            val afd = resources.openRawResourceFd(R.raw.beep)
            it.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
        }
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        } catch (e: Exception) {
        }
    }

    private fun stopAlarm() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        try {
            getSystemService(Vibrator::class.java)?.cancel()
        } catch (e: Exception) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
