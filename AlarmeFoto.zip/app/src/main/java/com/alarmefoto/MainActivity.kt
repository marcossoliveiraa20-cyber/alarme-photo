package com.alarmefoto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val dayNames = arrayOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb")

    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.header(this)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(16))
        val add = Button(this)
        add.text = "+ Novo alarme"
        add.setOnClickListener { newAlarm() }
        content.addView(add)
        val sv = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list)
        content.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Ui.footer(this))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
        checkPermissions()
    }

    // Pede, uma vez cada, as permissões que garantem que o alarme toque.
    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            if (Store.firstTime(this, "ask_notif")) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                return
            }
        }
        if (Build.VERSION.SDK_INT >= 34 &&
            !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        ) {
            if (Store.firstTime(this, "ask_fsi")) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:$packageName")
                    )
                )
                return
            }
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            if (Store.firstTime(this, "ask_batt")) {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
    }

    private fun daysText(d: Int): String {
        if (d == 0) return "Uma vez"
        if (d == 127) return "Todos os dias"
        return (0..6).filter { ((d shr it) and 1) == 1 }.joinToString(" ") { dayNames[it] }
    }

    private fun announce(a: Alarm) {
        val mins = (Scheduler.nextTrigger(a) - System.currentTimeMillis()) / 60000
        Toast.makeText(this, "Alarme toca em ${mins / 60}h ${mins % 60}min", Toast.LENGTH_LONG).show()
    }

    private fun render() {
        list.removeAllViews()
        val all = Store.load(this)
        if (all.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Nenhum alarme ainda.\nToque em \"+ Novo alarme\"."
            tv.setPadding(0, dp(24), 0, 0)
            list.addView(tv)
        }
        for (a in all.sortedBy { it.hour * 60 + it.minute }) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))

            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            val bmp = a.photo?.let { Photos.load(it, 256) }
            if (bmp != null) img.setImageBitmap(bmp)
            else img.setImageResource(android.R.drawable.ic_menu_gallery)
            img.setOnClickListener { pickPhoto(listOf(a.id)) }
            row.addView(img, LinearLayout.LayoutParams(dp(72), dp(72)))

            val tv = TextView(this)
            tv.text = "%02d:%02d\n%s".format(a.hour, a.minute, daysText(a.days))
            tv.textSize = 20f
            tv.setPadding(dp(12), 0, 0, 0)
            tv.setOnClickListener { editTime(a.id) }
            row.addView(
                tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )

            val sw = Switch(this)
            sw.isChecked = a.enabled
            sw.setOnCheckedChangeListener { _, on -> toggle(a.id, on) }
            row.addView(sw)

            val del = Button(this)
            del.text = "✕"
            del.setOnClickListener { confirmDelete(a.id) }
            row.addView(del)

            list.addView(row)
        }
    }

    private fun toggle(id: Int, on: Boolean) {
        val all = Store.load(this)
        val a = all.find { it.id == id } ?: return
        a.enabled = on
        if (on) {
            Scheduler.schedule(this, a)
            announce(a)
        } else {
            Scheduler.cancel(this, a)
        }
        Store.save(this, all)
    }

    private fun editTime(id: Int) {
        val all = Store.load(this)
        val a = all.find { it.id == id } ?: return
        TimePickerDialog(this, { _, h, m ->
            a.hour = h
            a.minute = m
            a.enabled = true
            Scheduler.schedule(this, a)
            Store.save(this, all)
            announce(a)
            render()
        }, a.hour, a.minute, true).show()
    }

    private fun confirmDelete(id: Int) {
        AlertDialog.Builder(this)
            .setTitle("Apagar este alarme?")
            .setPositiveButton("Apagar") { _, _ ->
                val all = Store.load(this)
                val a = all.find { it.id == id }
                if (a != null) {
                    Scheduler.cancel(this, a)
                    a.photo?.let { File(it).delete() }
                    all.remove(a)
                    Store.save(this, all)
                }
                render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun newAlarm() {
        val opts = arrayOf(
            "Horário normal (escolher dias)",
            "Remédio: de 4 em 4 horas",
            "Remédio: de 6 em 6 horas",
            "Remédio: de 8 em 8 horas",
            "Remédio: de 12 em 12 horas"
        )
        val steps = intArrayOf(0, 4, 6, 8, 12)
        AlertDialog.Builder(this)
            .setTitle("Tipo de alarme")
            .setItems(opts) { _, which ->
                val step = steps[which]
                val tp = TimePickerDialog(this, { _, h, m ->
                    if (step == 0) chooseDays(h, m) else createInterval(h, m, step)
                }, 8, 0, true)
                if (step != 0) tp.setTitle("Horário da primeira dose")
                tp.show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // Cria um alarme diário para cada dose do dia (ex.: 8 em 8 horas = 3 alarmes).
    private fun createInterval(h: Int, m: Int, step: Int) {
        val all = Store.load(this)
        val ids = mutableListOf<Int>()
        val times = mutableListOf<String>()
        for (k in 0 until 24 / step) {
            val a = Alarm(Store.nextId(all), (h + k * step) % 24, m, 127, true, null)
            all.add(a)
            ids.add(a.id)
            times.add("%02d:%02d".format(a.hour, a.minute))
            Scheduler.schedule(this, a)
        }
        Store.save(this, all)
        render()
        Toast.makeText(
            this, "Alarmes todos os dias: " + times.joinToString(", "), Toast.LENGTH_LONG
        ).show()
        askPhoto(ids)
    }

    private fun chooseDays(h: Int, m: Int) {
        val checked = BooleanArray(7)
        AlertDialog.Builder(this)
            .setTitle("Repetir em quais dias? (nenhum = uma vez)")
            .setMultiChoiceItems(dayNames, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Salvar") { _, _ ->
                var mask = 0
                for (i in 0..6) if (checked[i]) mask = mask or (1 shl i)
                val all = Store.load(this)
                val a = Alarm(Store.nextId(all), h, m, mask, true, null)
                all.add(a)
                Store.save(this, all)
                Scheduler.schedule(this, a)
                announce(a)
                render()
                askPhoto(listOf(a.id))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askPhoto(ids: List<Int>) {
        AlertDialog.Builder(this)
            .setTitle(if (ids.size > 1) "Adicionar foto aos alarmes?" else "Adicionar foto ao alarme?")
            .setPositiveButton("Escolher foto") { _, _ -> pickPhoto(ids) }
            .setNegativeButton("Continuar sem foto", null)
            .show()
    }

    private fun pickPhoto(ids: List<Int>) {
        Store.sp(this).edit().putString("pending_ids", ids.joinToString(",")).commit()
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 7 && resultCode == RESULT_OK && uri != null) {
            val ids = (Store.sp(this).getString("pending_ids", "") ?: "")
                .split(",").mapNotNull { it.toIntOrNull() }
            val all = Store.load(this)
            var changed = false
            for (id in ids) {
                val a = all.find { it.id == id } ?: continue
                val path = Photos.save(this, uri, a.id)
                if (path != null) {
                    a.photo?.let { File(it).delete() }
                    a.photo = path
                    changed = true
                }
            }
            if (changed) Store.save(this, all)
            render()
        }
    }
}
