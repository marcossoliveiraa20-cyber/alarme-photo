package com.alarmefoto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val dayNames = arrayOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb")

    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))
        val add = Button(this)
        add.text = "+ Novo alarme"
        add.setOnClickListener { newAlarm() }
        root.addView(add)
        val sv = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val footer = TextView(this)
        footer.text = "Criado por Aplicatico\nDesenvolvido por Marcos Oliviera"
        footer.textSize = 12f
        footer.gravity = Gravity.CENTER
        footer.setTextColor(0xFF777777.toInt())
        footer.setPadding(0, dp(8), 0, 0)
        root.addView(footer, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
        checkPermissions()
    }

    // Pede, uma vez cada, as permissões que garantem que o alarme toque.
    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            if (Store.firstTime(this, "ask_notif")) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                return
            }
        }
        if (Build.VERSION.SDK_INT >= 34 &&
            !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        ) {
            if (Store.firstTime(this, "ask_fsi")) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:$packageName")
                    )
                )
                return
            }
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            if (Store.firstTime(this, "ask_batt")) {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
    }

    private fun daysText(d: Int): String {
        if (d == 0) return "Uma vez"
        if (d == 127) return "Todos os dias"
        return (0..6).filter { ((d shr it) and 1) == 1 }.joinToString(" ") { dayNames[it] }
    }

    private fun announce(a: Alarm) {
        val mins = (Scheduler.nextTrigger(a) - System.currentTimeMillis()) / 60000
        Toast.makeText(this, "Alarme toca em ${mins / 60}h ${mins % 60}min", Toast.LENGTH_LONG).show()
    }

    private fun render() {
        list.removeAllViews()
        val all = Store.load(this)
        if (all.isEmpty()) {
            val tv = TextView(this)
            tv.text = "Nenhum alarme ainda.\nToque em \"+ Novo alarme\"."
            tv.setPadding(0, dp(24), 0, 0)
            list.addView(tv)
        }
        for (a in all) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))

            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            val bmp = a.photo?.let { Photos.load(it, 256) }
            if (bmp != null) img.setImageBitmap(bmp)
            else img.setImageResource(android.R.drawable.ic_menu_gallery)
            img.setOnClickListener { pickPhoto(a.id) }
            row.addView(img, LinearLayout.LayoutParams(dp(72), dp(72)))

            val tv = TextView(this)
            tv.text = "%02d:%02d\n%s".format(a.hour, a.minute, daysText(a.days))
            tv.textSize = 20f
            tv.setPadding(dp(12), 0, 0, 0)
            tv.setOnClickListener { editTime(a.id) }
            row.addView(
                tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )

            val sw = Switch(this)
            sw.isChecked = a.enabled
            sw.setOnCheckedChangeListener { _, on -> toggle(a.id, on) }
            row.addView(sw)

            val del = Button(this)
            del.text = "✕"
            del.setOnClickListener { confirmDelete(a.id) }
            row.addView(del)

            list.addView(row)
        }
    }

    private fun toggle(id: Int, on: Boolean) {
        val all = Store.load(this)
        val a = all.find { it.id == id } ?: return
        a.enabled = on
        if (on) {
            Scheduler.schedule(this, a)
            announce(a)
        } else {
            Scheduler.cancel(this, a)
        }
        Store.save(this, all)
    }

    private fun editTime(id: Int) {
        val all = Store.load(this)
        val a = all.find { it.id == id } ?: return
        TimePickerDialog(this, { _, h, m ->
            a.hour = h
            a.minute = m
            a.enabled = true
            Scheduler.schedule(this, a)
            Store.save(this, all)
            announce(a)
            render()
        }, a.hour, a.minute, true).show()
    }

    private fun confirmDelete(id: Int) {
        AlertDialog.Builder(this)
            .setTitle("Apagar este alarme?")
            .setPositiveButton("Apagar") { _, _ ->
                val all = Store.load(this)
                val a = all.find { it.id == id }
                if (a != null) {
                    Scheduler.cancel(this, a)
                    a.photo?.let { File(it).delete() }
                    all.remove(a)
                    Store.save(this, all)
                }
                render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun newAlarm() {
        TimePickerDialog(this, { _, h, m -> chooseDays(h, m) }, 7, 0, true).show()
    }

    private fun chooseDays(h: Int, m: Int) {
        val checked = BooleanArray(7)
        AlertDialog.Builder(this)
            .setTitle("Repetir em quais dias? (nenhum = uma vez)")
            .setMultiChoiceItems(dayNames, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Salvar") { _, _ ->
                var mask = 0
                for (i in 0..6) if (checked[i]) mask = mask or (1 shl i)
                val all = Store.load(this)
                val a = Alarm(Store.nextId(all), h, m, mask, true, null)
                all.add(a)
                Store.save(this, all)
                Scheduler.schedule(this, a)
                announce(a)
                render()
                pickPhoto(a.id)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun pickPhoto(id: Int) {
        Store.sp(this).edit().putInt("pending", id).commit()
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 7 && resultCode == RESULT_OK && uri != null) {
            val id = Store.sp(this).getInt("pending", -1)
            val all = Store.load(this)
            val a = all.find { it.id == id } ?: return
            val path = Photos.save(this, uri, a.id)
            if (path != null) {
                a.photo?.let { File(it).delete() }
                a.photo = path
                Store.save(this, all)
            }
            render()
        }
    }
}
