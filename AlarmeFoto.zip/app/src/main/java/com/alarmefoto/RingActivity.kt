package com.alarmefoto

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class RingActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val a = Store.load(this).find { it.id == intent.getIntExtra("id", -1) }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(48, 48, 48, 48)

        val bmp = a?.photo?.let { Photos.load(it, 1280) }
        if (bmp != null) {
            val iv = ImageView(this)
            iv.setImageBitmap(bmp)
            iv.adjustViewBounds = true
            root.addView(
                iv, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
                )
            )
        }

        val t = TextView(this)
        t.text = if (a != null) "%02d:%02d".format(a.hour, a.minute) else "Alarme"
        t.textSize = 56f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        root.addView(
            t, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val b = Button(this)
        b.text = "DESLIGAR"
        b.textSize = 24f
        b.setOnClickListener {
            startService(Intent(this, AlarmService::class.java).setAction("STOP"))
            finish()
        }
        root.addView(
            b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 220)
        )
        setContentView(root)
    }
}
