package com.alarmefoto

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class RingActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getIntExtra("id", -1)
        val a = Store.load(this).find { it.id == id }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(48, 48, 48, 32)

        val bmp = a?.photo?.let { Photos.load(it, 1280) }
        if (bmp != null) {
            val iv = ImageView(this)
            iv.setImageBitmap(bmp)
            iv.adjustViewBounds = true
            root.addView(
                iv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }

        val t = TextView(this)
        t.text = if (a != null) "%02d:%02d".format(a.hour, a.minute) else "Alarme"
        t.textSize = 56f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        root.addView(
            t, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val off = Button(this)
        off.text = "DESLIGAR"
        off.textSize = 20f
        off.setTextColor(Color.WHITE)
        off.setBackgroundColor(Color.rgb(211, 47, 47))
        off.setOnClickListener {
            startService(Intent(this, AlarmService::class.java).setAction("STOP"))
            finish()
        }
        val lp1 = LinearLayout.LayoutParams(0, 220, 1f)
        lp1.setMargins(0, 0, 12, 0)
        row.addView(off, lp1)

        val snooze = Button(this)
        snooze.text = "ADIAR 5 MIN"
        snooze.textSize = 20f
        snooze.setTextColor(Color.WHITE)
        snooze.setBackgroundColor(Color.rgb(25, 118, 210))
        snooze.setOnClickListener {
            startService(
                Intent(this, AlarmService::class.java).setAction("SNOOZE").putExtra("id", id)
            )
            finish()
        }
        val lp2 = LinearLayout.LayoutParams(0, 220, 1f)
        lp2.setMargins(12, 0, 0, 0)
        row.addView(snooze, lp2)

        root.addView(
            row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val footer = TextView(this)
        footer.text = "Aplicatico Desenvolvido por Marcos Oliviera"
        footer.textSize = 12f
        footer.setTextColor(Color.GRAY)
        footer.gravity = Gravity.CENTER
        footer.setPadding(0, 24, 0, 0)
        root.addView(
            footer, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        setContentView(root)
    }
}
