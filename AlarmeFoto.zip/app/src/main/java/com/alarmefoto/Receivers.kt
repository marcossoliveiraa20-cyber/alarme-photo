package com.alarmefoto

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val all = Store.load(c)
        val a = all.find { it.id == id } ?: return
        if (!a.enabled) return
        if (a.days == 0) a.enabled = false else Scheduler.schedule(c, a)
        Store.save(c, all)
        c.startForegroundService(Intent(c, AlarmService::class.java).putExtra("id", id))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        for (a in Store.load(c)) if (a.enabled) Scheduler.schedule(c, a)
    }
}
