package com.alarmefoto

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

// days: bitmask, bit 0 = domingo ... bit 6 = sábado. 0 = toca uma vez só.
data class Alarm(
    val id: Int,
    var hour: Int,
    var minute: Int,
    var days: Int,
    var enabled: Boolean,
    var photo: String?
)

// Tudo fica no armazenamento "protegido do dispositivo" para os alarmes
// funcionarem mesmo se o celular reiniciar e ainda não tiver sido desbloqueado.
object Store {
    private fun dpc(c: Context): Context = c.createDeviceProtectedStorageContext()
    fun sp(c: Context) = dpc(c).getSharedPreferences("alarms", Context.MODE_PRIVATE)
    fun dir(c: Context): File = dpc(c).filesDir

    fun load(c: Context): MutableList<Alarm> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        val out = mutableListOf<Alarm>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                Alarm(
                    o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getInt("d"),
                    o.getBoolean("e"), if (o.isNull("p")) null else o.getString("p")
                )
            )
        }
        return out
    }

    fun save(c: Context, list: List<Alarm>) {
        val arr = JSONArray()
        for (a in list) {
            val o = JSONObject()
            o.put("id", a.id)
            o.put("h", a.hour)
            o.put("m", a.minute)
            o.put("d", a.days)
            o.put("e", a.enabled)
            o.put("p", a.photo ?: JSONObject.NULL)
            arr.put(o)
        }
        sp(c).edit().putString("list", arr.toString()).commit()
    }

    fun nextId(list: List<Alarm>): Int = (list.maxOfOrNull { it.id } ?: 0) + 1

    // true só na primeira vez para cada chave (usado para pedir permissões uma vez)
    fun firstTime(c: Context, key: String): Boolean {
        val s = sp(c)
        if (s.getBoolean(key, false)) return false
        s.edit().putBoolean(key, true).commit()
        return true
    }
}

object Scheduler {
    fun nextTrigger(a: Alarm): Long {
        val now = System.currentTimeMillis()
        for (add in 0..7) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, add)
            c.set(Calendar.HOUR_OF_DAY, a.hour)
            c.set(Calendar.MINUTE, a.minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= now) continue
            val dow = c.get(Calendar.DAY_OF_WEEK) - 1
            if (a.days == 0 || ((a.days shr dow) and 1) == 1) return c.timeInMillis
        }
        return now + 24L * 3600L * 1000L
    }

    private fun pending(c: Context, a: Alarm): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", a.id)
        return PendingIntent.getBroadcast(
            c, a.id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // setAlarmClock é o mesmo mecanismo dos apps de relógio: toca na hora certa
    // mesmo com o celular em repouso (Doze) e com o app fechado.
    fun schedule(c: Context, a: Alarm) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(a), show), pending(c, a))
    }

    private fun snoozePending(c: Context, a: Alarm): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", a.id).putExtra("snooze", true)
        return PendingIntent.getBroadcast(
            c, 100000 + a.id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // Adiar: toca de novo daqui a alguns minutos (padrão: 5)
    fun snooze(c: Context, a: Alarm, minutes: Int = 5) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val at = System.currentTimeMillis() + minutes * 60_000L
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), snoozePending(c, a))
    }

    fun cancel(c: Context, a: Alarm) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, a))
        am.cancel(snoozePending(c, a))
    }
}

object Photos {
    fun save(c: Context, uri: Uri, id: Int): String? {
        val f = File(Store.dir(c), "foto_${id}_${System.currentTimeMillis()}.jpg")
        return try {
            c.contentResolver.openInputStream(uri)!!.use { input ->
                f.outputStream().use { out -> input.copyTo(out) }
            }
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun load(path: String, max: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = BitmapFactory.decodeFile(path, o2) ?: return null
            val ori = try {
                ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } catch (e: Exception) {
                1
            }
            val deg = when (ori) {
                6 -> 90f
                3 -> 180f
                8 -> 270f
                else -> 0f
            }
            if (deg == 0f) bmp else {
                val m = Matrix()
                m.postRotate(deg)
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
        } catch (e: Exception) {
            null
        }
    }
}
